
<div class="sidebar" id="sidebar">
  <div class="sidebar-header">
    <div class="sidebar-brand">
      <i class="bi bi-bank2"></i>
      <span>BankKu</span>
    </div>
  </div>

  <div class="sidebar-menu">
    
    <a href="#" class="menu-item active" data-section="dashboard">
      <i class="bi bi-speedometer2"></i>
      <span>Dashboard</span>
    </a>

    
    <a href="<?php echo e(route('nasabah.deposit.form')); ?>"
   class="menu-item <?php echo e(request()->routeIs('nasabah.deposit.*') ? 'active' : ''); ?>">
      <i class="bi bi-arrow-down-circle"></i>
      <span>Setor Dana</span>
    </a>

    
    <a href="<?php echo e(route('nasabah.withdraw.form')); ?>"
   class="menu-item <?php echo e(request()->routeIs('nasabah.withdraw.*') ? 'active' : ''); ?>">
      <i class="bi bi-arrow-up-circle"></i>
      <span>Tarik Dana</span>
  </a>

    
    <a href="#" class="menu-item" data-section="transactions">
      <i class="bi bi-clock-history"></i>
      <span>Riwayat Transaksi</span>
    </a>

    
    <a href="#" class="menu-item" data-section="profile">
      <i class="bi bi-person-circle"></i>
      <span>Profil Saya</span>
    </a>

    
    <a href="#" class="menu-item" data-section="dashboard" data-scroll="#pengaturan">
      <i class="bi bi-gear"></i>
      <span>Pengaturan</span>
    </a>

    
    <form method="POST" action="<?php echo e(route('logout')); ?>"
          style="margin-top:20px; border-top:1px solid #e5e7eb; padding-top:20px;">
      <?php echo csrf_field(); ?>
      <button type="submit" class="menu-item"
              style="width:100%; background:none; border:none; text-align:left;">
        <i class="bi bi-box-arrow-right"></i>
        <span>Keluar</span>
      </button>
    </form>
  </div>
</div>
<?php /**PATH C:\Users\laboo\BankMini\BankMiniLat\bank\resources\views/nasabah/partials/sidebar.blade.php ENDPATH**/ ?>