
<?php $__env->startSection('content'); ?>
<div class="container">
  <h3>Buat Teller Baru</h3>
  <form method="POST" action="<?php echo e(route('admin.teller.store')); ?>">
    <?php echo csrf_field(); ?>
    <input name="name" placeholder="Name" class="form-control mb-2" required>
    <input name="email" placeholder="Email" class="form-control mb-2" required>
    <input name="password" placeholder="Password" type="password" class="form-control mb-2" required>
    <button class="btn btn-success">Simpan</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\laboo\Documents\BankMiniLat\bank\resources\views/admin/create_teller.blade.php ENDPATH**/ ?>