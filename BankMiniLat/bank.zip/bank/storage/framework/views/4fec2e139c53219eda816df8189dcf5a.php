<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bank Mini</title>

    
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <?php echo $__env->yieldPushContent('styles'); ?>
    @livewireStyles
</head>
<body>
<?php
  $user = Auth::user();
?>

<?php if((!$user || ($user && !$user->isNasabah())) && !request()->is('layanan')): ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Bank Mini</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
      aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto">
        <?php if(auth()->guard()->check()): ?>
          <?php if($user->isAdmin()): ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
          <?php endif; ?>
          <?php if($user->isTeller()): ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('teller.dashboard')); ?>">Teller</a></li>
          <?php endif; ?>
        <?php endif; ?>
      </ul>

      <div class="d-flex align-items-center gap-2">
        <?php if(auth()->guard()->check()): ?>
          <span class="text-white small">Hi, <?php echo e($user->name); ?></span>
          <form method="POST" action="<?php echo e(route('logout')); ?>" class="m-0">
            <?php echo csrf_field(); ?>
            <button class="btn btn-sm btn-danger">Logout</button>
          </form>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
          <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-primary">Login</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
<?php endif; ?>


<?php if($user && $user->isNasabah()): ?>
  <div class="container-fluid p-0">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
<?php else: ?>
  <div class="container">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
@livewireScripts
</body>
</html>
<?php /**PATH C:\Users\laboo\BankMini\BankMiniLat\bank\resources\views/layouts/app.blade.php ENDPATH**/ ?>