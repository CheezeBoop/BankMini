
<?php $__env->startSection('content'); ?>
<div class="container">
  <h3>Admin Dashboard</h3>
  <p>Halo, <?php echo e(Auth::user()->name); ?>!</p>

  <h5>Daftar Teller</h5>
  <ul>
    <?php $__currentLoopData = $tellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($t->name); ?> (<?php echo e($t->email); ?>)
        <form action="<?php echo e(route('admin.teller.delete',$t->id)); ?>" method="POST" style="display:inline;">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button class="btn btn-sm btn-danger">Hapus</button>
        </form>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>

  <a href="<?php echo e(route('admin.teller.create')); ?>" class="btn btn-primary mt-3">+ Buat Teller Baru</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\laboo\Documents\BankMiniLat\bank\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>