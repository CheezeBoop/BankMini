<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4 py-4">
    <h3 class="mb-4">Pengaturan Limit Transaksi</h3>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">Minimal Setor</label>
            <input type="number" name="minimal_setor" class="form-control"
                value="<?php echo e(old('minimal_setor', $setting->minimal_setor)); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Maksimal Setor</label>
            <input type="number" name="maksimal_setor" class="form-control"
                value="<?php echo e(old('maksimal_setor', $setting->maksimal_setor)); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Minimal Tarik</label>
            <input type="number" name="minimal_tarik" class="form-control"
                value="<?php echo e(old('minimal_tarik', $setting->minimal_tarik)); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Maksimal Tarik</label>
            <input type="number" name="maksimal_tarik" class="form-control"
                value="<?php echo e(old('maksimal_tarik', $setting->maksimal_tarik)); ?>">
        </div>

        <button type="submit" class="btn btn-primary">
            <i class="bi bi-save me-1"></i> Simpan Pengaturan
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\laboo\BankMini\BankMiniLat\bank\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>